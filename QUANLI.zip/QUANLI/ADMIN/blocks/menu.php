<div class="top-menu">
    <span id="hello">Xin chào: <?php echo $hello ?></span>
    <img src="../ASSETS/img/IMG-Design/LOGO_khongchu.jpg">
    <span id="title_baogear">Báo Gear</span>
    <a href="logout.php">Đăng Xuất</a>
</div>

<ul>
    <li>
        <a href="?page=dssanpham">
            <i class="fa-regular fa-keyboard"></i>
            <span>Sản Phẩm</span>
        </a>
    </li> <!-- Thêm, Sửa, Xoá -->

    <li>
        <a href="?page=dskhachhang">
            <i class="fa-solid fa-users">

            </i><span>Khách Hàng</span>
        </a>
    </li> <!-- Xem -->

    <li>
        <a href="?page=dsdonhang">
            <i class="fa-regular fa-newspaper">

            </i><span>Đơn Hàng</span>
        </a>
    </li> <!-- Xem -->
    <!-- <li>
        <a href="?page=dschitietdonhang">
            <i class="fa-regular fa-file-lines"></i>
            <span>Chi Tiết Đơn</span>
        </a>
    </li> làm trực tiếp trong bảng dsdonhang, thêm cột chi tiết đơn -->

    <li>
        <a href="?page=dstaikhoan">
            <i class="fa-regular fa-user"></i>
            <span>Tài Khoản</span>
        </a>
    </li> <!-- Cấp TK, Xem TK, Xoá -->

    <li>
        <a href="?page=dsloai">
            <i class="fa-solid fa-layer-group"></i>
            <span>Loại</span>
        </a>
    </li> <!-- Thêm, Sửa, Xoá -->

</ul>
