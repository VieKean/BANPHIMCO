<!-- footer -->
<footer class="footer">
        <div class="wrapper">
            <div class="footer-container">

                <ul class="footer-list">
                    <li class="footer-item">
                        <h3 id="footer-item-title">Báo Gear</h3>
                        <ul class="footer-item_list">
                            <li class="footer-item_discription">
                                <p id="discription-location"> Địa chỉ:256 Đ.
                                    Nguyễn Văn Cừ, An Hoà,
                                    Ninh Kiều, Cần Thơ 900000 </p>
                            </li>
                        </ul>
                    </li>
                    <li class="footer-item">
                        <h3 id="footer-item-title"> Theo Dõi Chúng Tôi</h3>
                        <ul class="footer-item_list">
                            <li class="footer-item_discription">
                                <a href="https://www.facebook.com/phattai.ung/" id="discription-content">
                                    Facebook người thông minh giỏi gian đẹp trai thanh lịch nhất BÁO GEAR
                                    ( UNG PHÁT TÀI )
                                </a>
                            </li>
                            <li class="footer-item_discription">
                                <a href="" id="discription-content">
                                    Facebook nguyen hien vu
                                </a>
                            </li>
                            <li class="footer-item_discription">
                                <a href="" id="discription-content">
                                    Facebook Đoàn Gia Thịnh
                                </a>
                            </li>
                            <li class="footer-item_discription">
                                <a href="" id="discription-content">
                                    Facebook k
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="footer-item">
                        <h3 id="footer-item-title">Nhận thông báo khuyến mãi</h3>
                        <ul class="footer-item_list">
                            <li class="footer-item_discription">
                                <div class="footer-item-container">
                                    <input id="footer-discription_input" required=""
                                        placeholder="Nhập Email của Bạn....." type="email">
                                    <button class="footer-discription_button" type="button">
                                        <p id="footer-content-discription">Đăng ký</p>
                                    </button>
                                </div>
                            </li>
                        </ul>
                    </li>


                </ul>
            </div>
        </div>
    </footer>

    <!-- end Footer -->